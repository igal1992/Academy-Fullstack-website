import * as React from "react";

class itTeam extends React.Component{
    state = {
    }
    render(){
        return(
            <div align = {"center"}>
                <div>
                    <h1>IT Support</h1>
                    <br/>
                    <h2>in order to contact our Support Make sure you're registered in our University</h2>
                    <br/>
                    <p>IT Support Contact Phone:     <strong>*1111</strong></p>
                </div>
            </div>
        )
    }
}
export default itTeam;