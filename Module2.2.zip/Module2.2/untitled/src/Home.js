import * as React from "react";

class Home extends React.Component{
    state = {

    }
    render(){
        return(
            <div align= {"center"}>
                <div>
                    <h1>Welcome to Black Knight's University</h1>
                    <br/>
                    <h2>Study in one of the top Universities in Israel!</h2>
                    <br/>
                    <p>in our University you can Study a Variety of Choices:</p>
                </div>
            </div>
        )
    }
}
export default Home;